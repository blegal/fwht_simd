constexpr float Hadamard[2][2] = {
    {+1, +1},
    {+1, -1}
};
